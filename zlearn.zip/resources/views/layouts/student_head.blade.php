<!-- Prevent the demo from appearing in search engines -->
<meta name="robots"
content="noindex">

<link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CRoboto:400,500%7CExo+2:600&display=swap"
rel="stylesheet">

<!-- Preloader -->
{{-- <link type="text/css"
href="{{asset('Student/vendor/spinkit.css')}}"
rel="stylesheet"> --}}
<link href="{{asset('Student/vendor/spinkit.css')}}" rel="stylesheet" type="text/css" />


<!-- Perfect Scrollbar -->
<link type="text/css"
href="{{asset('Student/vendor/perfect-scrollbar.css')}}"
rel="stylesheet">

<!-- Material Design Icons -->
<link type="text/css"
href="{{asset('Student/css/material-icons.css')}}"
rel="stylesheet">

<!-- Font Awesome Icons -->
<link type="text/css"
href="{{asset('Student/css/fontawesome.css')}}"
rel="stylesheet">

<!-- Preloader -->
<link type="text/css"
href="{{asset('Student/css/preloader.css')}}"
rel="stylesheet">

<!-- App CSS -->
<link type="text/css"
href="{{asset('Student/css/app.css')}}"
rel="stylesheet">